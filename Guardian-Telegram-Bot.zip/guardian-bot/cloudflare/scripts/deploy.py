"""Interactive deployment. Tokens use hidden input and stdin, never command arguments."""
import getpass
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / ".deploy-state.json"
WRANGLER_VERSION = "4.152.0"


def run(args, *, capture=False, secret_input=None):
    executable = shutil.which(args[0])
    if not executable:
        raise SystemExit(f"Не найдена программа {args[0]}. См. README_RU.md.")
    # Use an argument list; secret input goes through stdin, never a shell command.
    result = subprocess.run([executable, *args[1:]], cwd=ROOT, text=True,
        input=secret_input, capture_output=capture or secret_input is not None,
        env={**os.environ, "WRANGLER_SEND_METRICS": "false", "NO_COLOR": "1"})
    if result.returncode:
        if secret_input is None:
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print(result.stderr)
        raise SystemExit("Команда завершилась ошибкой. Исправь причину и запусти установщик снова; секреты не напечатаны.")
    return result.stdout or ""


def wrangler(*args, **kwargs):
    return run(["npx", "--yes", f"wrangler@{WRANGLER_VERSION}", *args], **kwargs)


def telegram(token, method, **params):
    req = urllib.request.Request(f"https://api.telegram.org/bot{token}/{method}",
        data=json.dumps(params).encode(), headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            payload = json.load(response)
    except Exception:
        raise SystemExit("Не удалось связаться с Telegram. Проверь токен и сеть. Токен скрыт.") from None
    if not payload.get("ok"):
        raise SystemExit(f"Telegram отказал в операции, код {payload.get('error_code', '?')}. Токен скрыт.")
    return payload["result"]


def store(state):
    STATE.write_text(json.dumps(state, indent=2), encoding="utf-8")


def main():
    print("Guardian · Cloudflare Workers Free + D1\n")
    for required in ["node", "npx", "uv"]:
        if not shutil.which(required):
            raise SystemExit(f"Установи {required}. Пошаговая инструкция: README_RU.md")
    print("Используй Workers Free. Этот скрипт НЕ покупает тарифы и НЕ включает платные услуги.")
    if input("В панели Cloudflare выбран Workers Free? Введи FREE: ").strip() != "FREE":
        raise SystemExit("Размещение отменено. Сначала проверь бесплатный план аккаунта.")
    state = json.loads(STATE.read_text()) if STATE.exists() else {}
    if not os.getenv("CLOUDFLARE_API_TOKEN"):
        print("Откроется вход в Cloudflare. Разреши Wrangler доступ для размещения.")
        wrangler("login")
    wrangler("whoami")
    account = state.get("account_id") or input("Account ID нужного аккаунта из вывода выше: ").strip()
    if not re.fullmatch(r"[0-9a-f]{32}", account):
        raise SystemExit("Account ID должен содержать 32 шестнадцатеричных символа.")
    os.environ["CLOUDFLARE_ACCOUNT_ID"] = account
    state["account_id"] = account
    store(state)

    token = getpass.getpass("Токен бота из BotFather (ввод скрыт): ").strip()
    me = telegram(token, "getMe")
    print("Бот: @" + me["username"])
    if state.get("bot_id") and state["bot_id"] != me["id"]:
        raise SystemExit("Этот каталог уже связан с другим ботом. Используй отдельную копию проекта.")
    state["bot_id"] = me["id"]
    state.setdefault("worker_name", f"guardian-{me['id']}")
    state.setdefault("database_name", f"guardian-{me['id']}")
    store(state)
    old_webhook = telegram(token, "getWebhookInfo")
    if old_webhook.get("url"):
        if input("У бота уже настроен webhook. Заменить его этим проектом? Введи REPLACE: ").strip() != "REPLACE":
            raise SystemExit("Существующий webhook оставлен без изменений.")
    print("Останови прежний polling-процесс этого бота перед завершением установки.")

    if not state.get("database_id"):
        # Reuse only an explicitly selected same-name database after an interrupted run.
        listing = wrangler("d1", "list", "--json", capture=True)
        try:
            databases = json.loads(listing)
        except ValueError:
            databases = []
        existing = [d for d in databases if d.get("name") == state["database_name"]]
        if existing:
            if input("Найдена база с таким именем. Это база данного бота? Введи USE: ").strip() != "USE":
                raise SystemExit("База не изменена.")
            state["database_id"] = existing[0]["uuid"]
            store(state)
    if not state.get("database_id"):
        output = wrangler("d1", "create", state["database_name"], capture=True)
        print(output)
        match = re.search(r'"database_id"\s*:\s*"([0-9a-f-]{36})"', output)
        if not match:
            match = re.search(r'database_id\s*=\s*"([0-9a-f-]{36})"', output)
        database_id = match[1] if match else input("Database ID из вывода выше: ").strip()
        if not re.fullmatch(r"[0-9a-f-]{36}", database_id):
            raise SystemExit("Некорректный Database ID. Созданную базу не удаляй; сохрани её ID для повторного запуска.")
        state["database_id"] = database_id
        store(state)
    config = json.loads((ROOT/"wrangler.jsonc").read_text())
    config["name"] = state["worker_name"]
    config["account_id"] = account
    config["d1_databases"][0].update(database_id=state["database_id"], database_name=state["database_name"])
    (ROOT/"wrangler.jsonc").write_text(json.dumps(config, indent=2), encoding="utf-8")
    wrangler("d1", "execute", state["database_name"], "--remote", "--file", "schema.sql", "--yes")
    # First deployment is intentionally inert until secrets are installed.
    output = run(["uv", "run", "pywrangler", "deploy"], capture=True)
    print(output)
    urls = re.findall(r"https://[a-z0-9.-]+\.workers\.dev", output)
    worker_url = urls[-1] if urls else input("Адрес Worker https://…workers.dev из вывода выше: ").strip().rstrip("/")
    if not re.fullmatch(r"https://" + re.escape(state["worker_name"]) + r"\.[a-z0-9-]+\.workers\.dev", worker_url):
        raise SystemExit("Адрес не совпадает с именем размещённого Worker. Webhook не изменён.")
    secret = secrets.token_urlsafe(32)
    wrangler("secret", "bulk", secret_input=json.dumps({
        "BOT_TOKEN": token, "BOT_USERNAME": me["username"], "WEBHOOK_SECRET": secret}))
    # Verify the public endpoint before switching Telegram to it.
    try:
        with urllib.request.urlopen(worker_url + "/health", timeout=30) as response:
            if response.status != 200:
                raise ValueError()
    except Exception:
        raise SystemExit("Worker пока не отвечает на /health. Webhook не переключён. Повтори запуск после проверки Cloudflare.") from None
    telegram(token, "setWebhook", url=worker_url + "/telegram", secret_token=secret,
             max_connections=1, drop_pending_updates=False,
             allowed_updates=["message", "edited_message", "callback_query"])
    telegram(token, "setMyCommands", commands=[{"command": k, "description": v} for k,v in [
        ("help", "Справка"), ("settings", "Настройки"), ("rules", "Правила"),
        ("warn", "Предупреждение"), ("mute", "Мут"), ("ban", "Бан"),
        ("unmute", "Снять мут"), ("report", "Жалоба"), ("check", "Права бота")]])
    info = telegram(token, "getWebhookInfo")
    if info.get("url") != worker_url + "/telegram":
        raise SystemExit("Telegram не подтвердил нужный webhook. Проверь настройки.")
    state["worker_url"] = worker_url
    store(state)
    print("\nГотово: Worker опубликован, Telegram подтвердил webhook.")
    print("Добавь бота администратором супергруппы, отправь /ping и /check.")
    print("Сайт: " + worker_url + "/health")
    print("Полная проверка работы требует сообщения в Telegram; /health подтверждает только доступность HTTP.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        raise SystemExit("\nУстановка прервана.") from None
