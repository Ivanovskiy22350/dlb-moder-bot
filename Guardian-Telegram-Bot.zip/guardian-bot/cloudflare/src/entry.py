from workers import WorkerEntrypoint, Response
from guardian_cf.webhook import handle
from guardian_cf.db import Database


class Default(WorkerEntrypoint):
    async def fetch(self, request):
        status, body = await handle(request, self.env)
        return Response(body, status=status, headers={"Cache-Control": "no-store"})

    async def scheduled(self, controller, env, ctx):
        await Database(self.env.DB).prune()
