import json
import time
from .policy import DEFAULTS

try:
    from pyodide.ffi import jsnull
except ImportError:  # CPython tests
    jsnull = None


def native(value):
    if value is jsnull:
        return None
    value = value.to_py() if hasattr(value, "to_py") else value
    if isinstance(value, dict):
        return {k: native(v) for k, v in value.items()}
    if isinstance(value, list):
        return [native(v) for v in value]
    return value


class Database:
    def __init__(self, binding):
        self.binding = binding

    def statement(self, sql, args):
        # Pyodide maps Python None to JS undefined; D1 requires explicit null.
        return self.binding.prepare(sql).bind(*(jsnull if v is None else v for v in args))

    async def run(self, sql, *args):
        return native(await self.statement(sql, args).run())

    async def first(self, sql, *args):
        return native(await self.statement(sql, args).first())

    async def rows(self, sql, *args):
        result = native(await self.statement(sql, args).all())
        return result["results"]

    async def settings(self, chat):
        row = await self.first("SELECT value FROM settings WHERE chat=?", chat)
        saved = json.loads(row["value"]) if row else {}
        return {**DEFAULTS, **saved, "words": list(saved.get("words", []))}

    async def save_settings(self, chat, settings):
        await self.run("INSERT OR REPLACE INTO settings VALUES(?,?)", chat,
                       json.dumps(settings, ensure_ascii=False))

    async def count(self, chat, user):
        row = await self.first("SELECT count FROM warnings WHERE chat=? AND user=?", chat, user)
        return row["count"] if row else 0

    async def change_warns(self, chat, user, delta=0, reset=False):
        if reset:
            await self.run("DELETE FROM warnings WHERE chat=? AND user=?", chat, user)
            return 0
        row = await self.first("""INSERT INTO warnings VALUES(?,?,MAX(0,?))
            ON CONFLICT(chat,user) DO UPDATE SET count=MAX(0,count+?) RETURNING count""",
                               chat, user, delta, delta)
        return row["count"]

    async def audit(self, chat, actor, target, action, reason=""):
        await self.run("INSERT INTO audit(chat,actor,target,action,reason,at) VALUES(?,?,?,?,?,?)",
                       chat, actor, target, action, reason[:300], int(time.time()))

    async def logs(self, chat):
        return await self.rows("SELECT * FROM audit WHERE chat=? ORDER BY id DESC LIMIT 10", chat)

    async def stats(self, chat):
        return await self.rows("SELECT action,COUNT(*) AS n FROM audit WHERE chat=? GROUP BY action", chat)

    async def acquire(self, chat, owner):
        now = int(time.time())
        result = await self.first("""INSERT INTO chat_locks VALUES(?,?,?)
            ON CONFLICT(chat) DO UPDATE SET owner=excluded.owner, expires=excluded.expires
            WHERE chat_locks.expires<=? RETURNING owner""", chat, owner, now+120, now)
        return bool(result)

    async def release(self, chat, owner):
        await self.run("DELETE FROM chat_locks WHERE chat=? AND owner=?", chat, owner)

    async def claim(self, update_id):
        row = await self.first("INSERT OR IGNORE INTO updates VALUES(?,'processing',?,NULL) RETURNING id",
                               update_id, int(time.time()))
        return bool(row)

    async def finish(self, update_id, state="done"):
        await self.run("UPDATE updates SET state=?,finished=? WHERE id=?", state, int(time.time()), update_id)

    async def prune(self):
        # Batch size limits keep scheduled invocations within the free plan CPU/query limits.
        now = int(time.time())
        for table, column, cutoff in [("audit", "at", now-90*86400),
                                      ("ephemeral", "expires", now), ("chat_locks", "expires", now),
                                      ("updates", "started", now-7*86400)]:
            await self.run(f"DELETE FROM {table} WHERE rowid IN (SELECT rowid FROM {table} WHERE {column}<? LIMIT 1000)", cutoff)


class PersistentCooldowns:
    def __init__(self, db):
        self.db = db

    async def ready(self, key, seconds):
        now = time.time()
        key = "cooldown:" + json.dumps(key)
        row = await self.db.first("""INSERT INTO ephemeral VALUES(?,'1',?)
            ON CONFLICT(key) DO UPDATE SET expires=excluded.expires
            WHERE ephemeral.expires<=? RETURNING key""", key, now+seconds, now)
        return bool(row)


class PersistentFlood:
    def __init__(self, db):
        self.db = db

    async def hit(self, chat, user, limit, window):
        # The webhook holds a D1 chat lease, so this read/write pair is serialized.
        now = time.time()
        key = f"flood:{chat}:{user}"
        row = await self.db.first("SELECT value FROM ephemeral WHERE key=? AND expires>?", key, now)
        times = [t for t in json.loads(row["value"]) if t > now-window] if row else []
        times.append(now)
        await self.db.run("INSERT OR REPLACE INTO ephemeral VALUES(?,?,?)", key,
                          json.dumps(times[-31:]), now+window)
        return len(times) > limit
