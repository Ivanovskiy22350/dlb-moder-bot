"""Small Telegram Bot API transport using Workers fetch; no aiohttp or threads."""
import json
from datetime import datetime


class TelegramAPIError(Exception):
    def __init__(self, code=0):
        self.code = code
        super().__init__(f"Telegram API error {code}")


class Object:
    def __init__(self, **values):
        self.__dict__.update(values)

    def __getattr__(self, key):
        return None

    @property
    def full_name(self):
        return " ".join(x for x in [self.first_name, self.last_name] if x)


def wrap(value):
    if isinstance(value, dict):
        return Object(**{k: wrap(v) for k, v in value.items()})
    if isinstance(value, list):
        return [wrap(v) for v in value]
    return value


def encode(value):
    if isinstance(value, Object):
        return {k: encode(v) for k, v in value.__dict__.items() if v is not None and not k.startswith('_')}
    if isinstance(value, datetime):
        return int(value.timestamp())
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items() if v is not None}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    return value


class ChatPermissions(Object):
    model_fields = {k: None for k in (
        "can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos",
        "can_send_videos", "can_send_video_notes", "can_send_voice_notes", "can_send_polls",
        "can_send_other_messages", "can_add_web_page_previews", "can_change_info",
        "can_invite_users", "can_pin_messages", "can_manage_topics", "can_react_to_messages",
        "can_edit_tag")}


class InlineKeyboardButton(Object):
    pass


class InlineKeyboardMarkup(Object):
    pass


class Message(Object):
    def __init__(self, raw, bot):
        values = {k: wrap(v) for k, v in raw.items() if k != "reply_to_message"}
        values["from_user"] = values.pop("from", None)
        super().__init__(**values)
        self._bot = bot
        self.reply_to_message = Message(raw["reply_to_message"], bot) if raw.get("reply_to_message") else None
        self.content_type = next((k for k in (
            "new_chat_members", "left_chat_member", "pinned_message", "new_chat_title",
            "new_chat_photo", "delete_chat_photo", "group_chat_created", "supergroup_chat_created",
            "text", "photo", "video", "sticker", "document", "animation", "voice", "audio"
        ) if raw.get(k) is not None), "other")

    async def answer(self, text, **kwargs):
        return await self._bot.call("sendMessage", chat_id=self.chat.id, text=text,
            message_thread_id=self.message_thread_id, link_preview_options={"is_disabled": True}, **kwargs)

    async def reply(self, text, **kwargs):
        return await self.answer(text, reply_parameters={"message_id": self.message_id,
                                                        "allow_sending_without_reply": True}, **kwargs)

    async def edit_text(self, text, **kwargs):
        return await self._bot.call("editMessageText", chat_id=self.chat.id, message_id=self.message_id,
                                    text=text, **kwargs)


class CallbackQuery(Object):
    def __init__(self, raw, bot):
        super().__init__(id=raw["id"], data=raw.get("data"), from_user=wrap(raw.get("from", {})))
        self.message = Message(raw["message"], bot) if raw.get("message", {}).get("date") else None
        self._bot = bot

    async def answer(self, text, show_alert=False):
        return await self._bot.call("answerCallbackQuery", callback_query_id=self.id,
                                    text=text, show_alert=show_alert)


class Bot:
    def __init__(self, token, transport=None):
        self._token = token
        self.id = int(token.split(":", 1)[0])
        self._transport = transport

    async def call(self, method, **params):
        if self._transport:
            return await self._transport(method, encode(params))
        from workers import fetch
        try:
            response = await fetch(f"https://api.telegram.org/bot{self._token}/{method}",
                                   method="POST", headers={"Content-Type": "application/json"},
                                   body=json.dumps(encode(params), ensure_ascii=False))
            payload = await response.json()
        except Exception:
            # Never surface a URL containing the token to logs or chat.
            raise TelegramAPIError(0) from None
        if not payload.get("ok"):
            raise TelegramAPIError(payload.get("error_code", 0))
        return payload.get("result")

    async def get_chat_member(self, chat_id, user_id):
        return wrap(await self.call("getChatMember", chat_id=chat_id, user_id=user_id))

    async def restrict_chat_member(self, chat_id, user_id, **kwargs):
        return await self.call("restrictChatMember", chat_id=chat_id, user_id=user_id, **kwargs)

    async def ban_chat_member(self, chat_id, user_id):
        return await self.call("banChatMember", chat_id=chat_id, user_id=user_id)

    async def unban_chat_member(self, chat_id, user_id, **kwargs):
        return await self.call("unbanChatMember", chat_id=chat_id, user_id=user_id, **kwargs)

    async def delete_message(self, chat_id, message_id):
        return await self.call("deleteMessage", chat_id=chat_id, message_id=message_id)
