"""Authenticated webhook, persistent deduplication, per-chat lease."""
import asyncio
import hmac
import json
import secrets
import time

from .app import Guardian
from .db import Database
from .telegram import Bot, CallbackQuery, Message


def verified(given, expected):
    return bool(expected and given and hmac.compare_digest(given.encode(), expected.encode()))


async def process_update(update, db, bot, username):
    if not isinstance(update, dict) or type(update.get("update_id")) is not int:
        return 400, "Invalid update"
    event = update.get("message") or update.get("edited_message")
    callback = update.get("callback_query")
    if not event and not callback:
        return 200, "Ignored"
    context = event or callback.get("message", {})
    chat = context.get("chat", {}).get("id")
    if type(chat) is not int:
        return 200, "Ignored"
    # Telegram retains updates for at most 24 hours; do not execute stale actions.
    timestamp = context.get("edit_date") or context.get("date", 0)
    if event and timestamp and timestamp < time.time()-86400:
        return 200, "Expired"
    uid = update["update_id"]
    owner = secrets.token_hex(16)
    if not await db.acquire(chat, owner):
        return 503, "Busy"
    claimed = False
    try:
        if not await db.claim(uid):
            # Do not replay external side effects after a crash. Expose via /logs.
            state = await db.first("SELECT state FROM updates WHERE id=?", uid)
            if state and state["state"] == "processing":
                await db.finish(uid, "interrupted")
                await db.audit(chat, bot.id, None, "interrupted", f"update_id={uid}")
            return 200, "Duplicate"
        claimed = True
        app = Guardian(bot, db, username)
        if callback:
            await app.callback(CallbackQuery(callback, bot))
        else:
            await app.message(Message(event, bot))
        await db.finish(uid)
        return 200, "OK"
    except Exception as exc:
        if claimed:
            # Acknowledging prevents uncertain moderation effects from being repeated.
            await db.finish(uid, "failed")
            await db.audit(chat, bot.id, None, "failed", f"update_id={uid}; {type(exc).__name__}")
            print("Guardian update failed:", uid, type(exc).__name__)
            return 200, "Recorded failure"
        raise
    finally:
        await db.release(chat, owner)


async def handle(request, env):
    from urllib.parse import urlsplit
    path = urlsplit(request.url).path
    if request.method == "GET" and path == "/health":
        return 200, "Guardian webhook is available"
    if path != "/telegram":
        return 404, "Not found"
    if request.method != "POST":
        return 405, "Method not allowed"
    secret = getattr(env, "WEBHOOK_SECRET", "")
    if not verified(request.headers.get("X-Telegram-Bot-Api-Secret-Token"), secret):
        return 403, "Forbidden"
    if not getattr(env, "BOT_TOKEN", "") or not getattr(env, "BOT_USERNAME", ""):
        return 503, "Not configured"
    # Telegram webhook bodies are JSON, and media arrives as metadata, not file bytes.
    if "application/json" not in (request.headers.get("Content-Type") or "").lower():
        return 415, "JSON required"
    length = request.headers.get("Content-Length")
    if length and (not length.isdigit() or int(length) > 1048576):
        return 413, "Too large"
    body = await request.text()
    if len(body.encode()) > 1048576:
        return 413, "Too large"
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        return 400, "Invalid JSON"
    db = Database(env.DB)
    bot = Bot(env.BOT_TOKEN)
    try:
        return await asyncio.wait_for(process_update(data, db, bot, env.BOT_USERNAME), timeout=25)
    except Exception as exc:
        print("Guardian webhook unavailable:", type(exc).__name__)
        return 503, "Retry later"
