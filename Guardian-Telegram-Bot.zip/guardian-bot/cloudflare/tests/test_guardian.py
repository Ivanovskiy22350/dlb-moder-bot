import asyncio
import json
import sqlite3
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from guardian_cf.app import Guardian
from guardian_cf.db import Database, PersistentCooldowns, PersistentFlood
from guardian_cf.telegram import Bot, Message, TelegramAPIError
from guardian_cf.webhook import handle, process_update, verified


class Statement:
    def __init__(self, conn, sql, args=()):
        self.conn, self.sql, self.args = conn, sql, args

    def bind(self, *args):
        return Statement(self.conn, self.sql, args)

    async def first(self):
        row = self.conn.execute(self.sql, self.args).fetchone()
        self.conn.commit()
        return dict(row) if row else None

    async def run(self):
        cur = self.conn.execute(self.sql, self.args)
        cur.fetchall()
        self.conn.commit()
        return {"success": True, "meta": {"changes": cur.rowcount}}

    async def all(self):
        rows = self.conn.execute(self.sql, self.args).fetchall()
        self.conn.commit()
        return {"results": [dict(r) for r in rows], "success": True}


class Binding:
    def __init__(self):
        self.conn = sqlite3.connect(":memory:")
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript((Path(__file__).parents[1]/"schema.sql").read_text())

    def prepare(self, sql):
        return Statement(self.conn, sql)


@pytest.fixture
def db():
    binding = Binding()
    yield Database(binding)
    binding.conn.close()


class Telegram:
    def __init__(self):
        self.calls = []
        self.restricted = set()
        self.demoted = set()
        self.fail_mute = False

    async def __call__(self, method, params):
        self.calls.append((method, params))
        if method == "getChatMember":
            uid = params["user_id"]
            return {"status": "restricted" if uid in self.restricted else
                    ("administrator" if uid in {1, 999} and uid not in self.demoted else "member"),
                    "can_restrict_members": True, "can_delete_messages": True}
        if method == "restrictChatMember" and self.fail_mute:
            raise TelegramAPIError(403)
        return True


def update(text="/ping", actor=1, update_id=1, edited=False):
    event = {"message_id": 10, "date": int(time.time()), "chat": {"id": -100123, "type": "supergroup"},
             "from": {"id": actor, "first_name": "Test", "is_bot": False}, "text": text}
    if edited:
        event["edit_date"] = int(time.time())
    return {"update_id": update_id, "edited_message" if edited else "message": event}


def bot(api):
    return Bot("999:LOCAL_TEST_TOKEN_ONLY", api)


@pytest.mark.asyncio
async def test_duplicate_warn_once(db):
    api = Telegram()
    data = update("!варн 5 спам")
    assert (await process_update(data, db, bot(api), "guardbot"))[0] == 200
    assert (await process_update(data, db, bot(api), "guardbot"))[1] == "Duplicate"
    assert await db.count(-100123, 5) == 1
    assert len([c for c in api.calls if c[0] == "sendMessage"]) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("cmd", ["!бан 5", "/mute 5 10m", "/set warn_limit 10", "/resetwarns 5"])
async def test_unauthorized_commands(db, cmd):
    api = Telegram()
    await process_update(update(cmd, actor=2), db, bot(api), "guardbot")
    assert not any(m in {"banChatMember", "restrictChatMember"} for m, _ in api.calls)
    assert (await db.settings(-100123))["warn_limit"] == 3
    assert any("администраторам" in p.get("text", "") for _, p in api.calls)


@pytest.mark.asyncio
async def test_admin_mute_serializes_permissions_and_time(db):
    api = Telegram()
    await process_update(update("!мут 5 30м спам"), db, bot(api), "guardbot")
    params = next(p for m, p in api.calls if m == "restrictChatMember")
    assert params["user_id"] == 5
    assert type(params["until_date"]) is int
    assert params["until_date"] > time.time()+1700
    assert all(v is False for v in params["permissions"].values())


@pytest.mark.asyncio
@pytest.mark.parametrize("uid", [1, 999])
async def test_protected_targets(db, uid):
    api = Telegram()
    await process_update(update(f"/ban {uid}"), db, bot(api), "guardbot")
    assert not any(m == "banChatMember" for m, _ in api.calls)


@pytest.mark.asyncio
async def test_edited_command_does_not_execute(db):
    api = Telegram()
    await process_update(update("/ban 5", edited=True), db, bot(api), "guardbot")
    assert not any(m == "banChatMember" for m, _ in api.calls)


@pytest.mark.asyncio
async def test_edited_hidden_link_filtered(db):
    api = Telegram()
    s = await db.settings(-100123)
    s["antilinks"] = True
    await db.save_settings(-100123, s)
    data = update("", actor=5, edited=True)
    data["edited_message"].update(text=None, caption="нажми", caption_entities=[
        {"type": "text_link", "offset": 0, "length": 5, "url": "https://example.org"}])
    await process_update(data, db, bot(api), "guardbot")
    assert any(m == "deleteMessage" for m, _ in api.calls)
    assert await db.count(-100123, 5) == 1


@pytest.mark.asyncio
async def test_flood_survives_new_instances(db):
    api = Telegram()
    for i in range(8):
        await process_update(update("text", actor=5, update_id=i), Database(db.binding), bot(api), "guardbot")
    assert sum(m == "restrictChatMember" for m, _ in api.calls) == 1


@pytest.mark.asyncio
async def test_warn_reset_only_on_success(db):
    api = Telegram()
    api.fail_mute = True
    for i in range(3):
        await process_update(update("/warn 5", update_id=i), db, bot(api), "guardbot")
    assert await db.count(-100123, 5) == 3
    api.fail_mute = False
    await process_update(update("/warn 5", update_id=4), db, bot(api), "guardbot")
    assert await db.count(-100123, 5) == 0


@pytest.mark.asyncio
async def test_callback_demoted_user_cannot_toggle(db):
    api = Telegram()
    api.demoted.add(1)
    data = {"update_id": 1, "callback_query": {"id": "query", "data": "toggle:antilinks",
            "from": {"id": 1}, "message": update()["message"]}}
    await process_update(data, db, bot(api), "guardbot")
    assert not (await db.settings(-100123))["antilinks"]
    assert any(m == "answerCallbackQuery" and p["show_alert"] for m, p in api.calls)


@pytest.mark.asyncio
async def test_callback_admin_toggles_and_edits(db):
    api = Telegram()
    data = {"update_id": 1, "callback_query": {"id": "query", "data": "toggle:antilinks",
            "from": {"id": 1}, "message": update()["message"]}}
    await process_update(data, db, bot(api), "guardbot")
    assert (await db.settings(-100123))["antilinks"]
    params = next(p for m, p in api.calls if m == "editMessageText")
    assert params["reply_markup"]["inline_keyboard"]


@pytest.mark.asyncio
async def test_unban_and_existing_restriction(db):
    api = Telegram()
    await process_update(update("/unban 5"), db, bot(api), "guardbot")
    assert ("unbanChatMember", {"chat_id": -100123, "user_id": 5, "only_if_banned": True}) in api.calls
    api.restricted.add(5)
    await process_update(update("/mute 5 10m", update_id=2), db, bot(api), "guardbot")
    assert not any(m == "restrictChatMember" for m, _ in api.calls)


@pytest.mark.asyncio
async def test_reply_target_and_topic(db):
    api = Telegram()
    data = update("/warn спам")
    data["message"]["message_thread_id"] = 40
    data["message"]["reply_to_message"] = update("text", actor=5)["message"]
    await process_update(data, db, bot(api), "guardbot")
    assert await db.count(-100123, 5) == 1
    assert next(p for m, p in api.calls if m == "sendMessage")["message_thread_id"] == 40


@pytest.mark.asyncio
async def test_claim_lock_and_chat_isolation(db):
    results = await asyncio.gather(*(db.acquire(1, str(i)) for i in range(10)))
    assert sum(results) == 1
    assert await db.acquire(2, "other")
    assert (await process_update(update(), db, bot(Telegram()), "guardbot"))[0] == 200
    await db.change_warns(1, 5, 1)
    assert await db.count(2, 5) == 0
    assert await db.claim(50)
    assert not await Database(db.binding).claim(50)


@pytest.mark.asyncio
async def test_interrupted_update_never_replays(db):
    api = Telegram()
    await db.claim(1)
    await process_update(update("/warn 5"), db, bot(api), "guardbot")
    assert await db.count(-100123, 5) == 0
    assert (await db.logs(-100123))[0]["action"] == "interrupted"


@pytest.mark.asyncio
async def test_cooldown_persistent_and_prune(db):
    assert await PersistentCooldowns(db).ready((1, 2), 60)
    assert not await PersistentCooldowns(Database(db.binding)).ready((1, 2), 60)
    await db.run("INSERT INTO ephemeral VALUES('expired','1',1)")
    await db.prune()
    assert not await db.first("SELECT * FROM ephemeral WHERE key='expired'")


class Request:
    method = "POST"
    url = "https://example.workers.dev/telegram"
    def __init__(self, secret="correct", body='{}'):
        self.headers = {"X-Telegram-Bot-Api-Secret-Token": secret, "Content-Type": "application/json"}
        self.body = body
    async def text(self):
        return self.body


@pytest.mark.asyncio
async def test_webhook_auth_before_database_access():
    env = SimpleNamespace(WEBHOOK_SECRET="correct", BOT_TOKEN="999:test", BOT_USERNAME="test")
    assert (await handle(Request("wrong"), env))[0] == 403
    assert (await handle(Request(body="not json"), env))[0] == 400
    assert (await handle(Request(body="x"*1048577), env))[0] == 413
    assert not verified("anything", "")


@pytest.mark.asyncio
async def test_webhook_routes():
    req = Request()
    req.method = "GET"
    req.url = "https://example.workers.dev/health"
    assert (await handle(req, SimpleNamespace()))[0] == 200
    req.url = "https://example.workers.dev/telegram"
    assert (await handle(req, SimpleNamespace()))[0] == 405
