"""Guardian: Telegram supergroup moderation."""
