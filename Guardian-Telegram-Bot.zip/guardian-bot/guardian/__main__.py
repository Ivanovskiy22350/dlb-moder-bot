import asyncio
import logging
import os
from contextlib import suppress

from aiogram import Bot
from aiogram.exceptions import TelegramUnauthorizedError
from aiogram.types import BotCommand
from dotenv import load_dotenv

from .app import Guardian
from .db import Database


class RedactToken(logging.Filter):
    def __init__(self, token):
        super().__init__()
        self.token = token

    def filter(self, record):
        record.msg = record.getMessage().replace(self.token, "[REDACTED]")
        record.args = ()
        return True


async def cleanup(db):
    while True:
        await asyncio.sleep(86400)
        await db.prune()


async def main():
    load_dotenv()
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token or token == "PASTE_TOKEN_HERE":
        raise SystemExit("Задай BOT_TOKEN в .env или в секретах хостинга. См. README_RU.md")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    for handler in logging.getLogger().handlers:
        handler.addFilter(RedactToken(token))
    # Never enable HTTP debug logging: URLs can contain the bot token.
    db = await Database(os.getenv("DB_PATH", "data/guardian.sqlite3")).open()
    task = None
    try:
        async with Bot(token=token) as bot:
            me = await bot.get_me()
            webhook = await bot.get_webhook_info()
            if webhook.url:
                if os.getenv("RESET_WEBHOOK", "false").casefold() != "true":
                    raise SystemExit("У бота уже есть webhook. Останови старый сервис и задай RESET_WEBHOOK=true для перехода на polling.")
                await bot.delete_webhook(drop_pending_updates=False)
            await bot.set_my_commands([BotCommand(command=k, description=v) for k, v in [
                ("help", "Справка"), ("settings", "Настройки группы"), ("rules", "Правила"),
                ("warn", "Предупреждение"), ("mute", "Мут"), ("ban", "Бан"),
                ("unmute", "Снять мут"), ("unban", "Снять бан"), ("report", "Жалоба"),
                ("check", "Проверка прав"), ("id", "ID пользователя и группы"),
            ]])
            app = Guardian(bot, db, me.username or "")
            task = asyncio.create_task(cleanup(db))
            logging.info("Guardian started as @%s", me.username)
            await app.dispatcher().start_polling(bot, allowed_updates=["message", "edited_message", "callback_query"],
                                                 tasks_concurrency_limit=100)
    except TelegramUnauthorizedError:
        raise SystemExit("Telegram отклонил токен. Проверь секрет BOT_TOKEN.") from None
    finally:
        if task:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
        await db.close()


if __name__ == "__main__":
    asyncio.run(main())
