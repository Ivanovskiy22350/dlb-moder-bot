import asyncio
import logging
import time
from contextlib import suppress
from datetime import datetime, timedelta, timezone
from weakref import WeakValueDictionary

from aiogram import Bot, Dispatcher, F
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.types import (
    Message, CallbackQuery, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup,
)

from .db import Database
from .policy import (BOOL_KEYS, LIMITS, Cooldowns, FloodGuard, contains_link,
                     duration, forbidden_word, parse_command, normalize)

log = logging.getLogger(__name__)
ADMINS = {"creator", "administrator"}
GROUPS = {"supergroup"}
HELP = """🛡 Guardian — модерация группы

Команды можно писать с / или !. Русские варианты: !бан, !разбан, !мут, !размут, !варн, !преды, !кик, !пинг.

Ответом на сообщение участника:
/warn причина — предупреждение
/mute 30m причина — мут (m/м, h/ч, d/д)
/ban причина — постоянный бан
/kick причина — удалить, разрешив вернуться
/unmute — снять персональные ограничения
/unban — разрешить вернуться
/unwarn — снять один варн
/resetwarns — сбросить варны
/warnings — число варнов
/del — удалить одно сообщение
/report причина — жалоба в группе

Без ответа укажи числовой ID: /mute 123456789 30m причина.
@username не используется для наказания: надёжнее ответ или ID.

/settings — кнопки настроек
/set warn_limit 3
/set mute_minutes 60
/set flood_limit 7
/set flood_window 10
/word add слово — добавить стоп-слово/фразу
/word del слово — удалить
/word list — список
/setrules текст — правила
/setwelcome текст с {name} — приветствие
/rules — правила • /filters — режимы фильтров
/logs — последние действия • /stats — статистика за 90 дней
/check — проверить права бота • /id — ID • /ping — статус

По умолчанию: антифлуд 8-е сообщение за 10 секунд → мут на 60 минут; 3 варна → мут. Ссылки и пересылки разрешены. Фильтры не применяются к администраторам.
Работаю в супергруппах. /help — эта справка."""


class UserError(Exception):
    pass


class Guardian:
    def __init__(self, bot: Bot, db: Database, username: str):
        self.bot, self.db, self.username = bot, db, username
        self.flood, self.cooldowns = FloodGuard(), Cooldowns()
        self.locks = WeakValueDictionary()
        self.started = time.monotonic()

    def lock(self, chat):
        lock = self.locks.get(chat)
        if lock is None:
            lock = self.locks[chat] = asyncio.Lock()
        return lock

    async def is_admin(self, chat, user):
        member = await self.bot.get_chat_member(chat, user)
        return member.status in ADMINS

    async def require_admin(self, chat, user, right=None):
        member = await self.bot.get_chat_member(chat, user)
        if member.status not in ADMINS:
            raise UserError("Эта команда доступна администраторам группы.")
        if right and member.status != "creator" and not getattr(member, right, False):
            raise UserError("У тебя нет необходимого права администратора: " + right)

    async def require_bot(self, chat, right):
        member = await self.bot.get_chat_member(chat, self.bot.id)
        if member.status != "administrator" or not getattr(member, right, False):
            raise UserError("Выдай боту право администратора: " + right + ". Проверка: /check")

    async def target(self, m, args, protect=True):
        reply = m.reply_to_message
        if reply:
            if reply.sender_chat or not reply.from_user:
                raise UserError("Сообщение отправлено от имени канала/группы. Выбери пользователя.")
            uid, rest = reply.from_user.id, args
        else:
            pieces = args.split(maxsplit=1)
            if not pieces or not pieces[0].isdigit() or not 0 < int(pieces[0]) < 2**52:
                raise UserError("Ответь на сообщение участника или укажи его числовой ID.")
            uid, rest = int(pieces[0]), pieces[1] if len(pieces) > 1 else ""
        if protect:
            if uid in {self.bot.id, m.from_user.id} or await self.is_admin(m.chat.id, uid):
                raise UserError("Нельзя применить наказание к себе, боту или администратору.")
        return uid, rest

    async def mute(self, chat, uid, seconds):
        # Do not shorten an existing restriction or discard its custom permissions.
        member = await self.bot.get_chat_member(chat, uid)
        if member.status in ADMINS or uid == self.bot.id:
            raise UserError("Участник защищён от модерации.")
        if member.status == "restricted":
            raise UserError("Участник уже ограничен. Существующее ограничение сохранено.")
        if member.status in {"left", "kicked"}:
            raise UserError("Участник сейчас не состоит в группе.")
        await self.bot.restrict_chat_member(
            chat, uid, permissions=ChatPermissions(**{k: False for k in ChatPermissions.model_fields}),
            until_date=datetime.now(timezone.utc) + timedelta(seconds=seconds),
            use_independent_chat_permissions=True,
        )

    async def warn(self, m, uid, reason, actor):
        settings = await self.db.settings(m.chat.id)
        count = await self.db.change_warns(m.chat.id, uid, 1)
        await self.db.audit(m.chat.id, actor, uid, "warn", reason)
        suffix = ""
        if count >= settings["warn_limit"]:
            try:
                await self.require_bot(m.chat.id, "can_restrict_members")
                await self.mute(m.chat.id, uid, settings["mute_minutes"] * 60)
            except (TelegramAPIError, UserError):
                suffix = "\nАвтомут не выполнен; варны сохранены. Проверь /check и текущие ограничения."
            else:
                await self.db.audit(m.chat.id, self.bot.id, uid, "automute", "Лимит предупреждений")
                await self.db.change_warns(m.chat.id, uid, reset=True)
                suffix = f"\nМут на {settings['mute_minutes']} мин. Счётчик сброшен."
        await m.answer(f"⚠️ ID {uid}: предупреждение {count}/{settings['warn_limit']}.\n{reason[:300]}{suffix}")

    def keyboard(self, settings):
        labels = {"antiflood": "Антифлуд", "antilinks": "Запрет ссылок",
                  "antiforward": "Запрет пересылок", "stopwords": "Стоп-слова", "welcome": "Приветствие"}
        return InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=f"{'✅' if settings[k] else '⬜'} {v}", callback_data=f"toggle:{k}")
        ] for k, v in labels.items()])

    def settings_text(self, s):
        return ("⚙️ Настройки этой группы\n"
                f"Антифлуд: более {s['flood_limit']} сообщений за {s['flood_window']} сек.\n"
                f"Лимит варнов: {s['warn_limit']}; мут: {s['mute_minutes']} мин.\n"
                f"Стоп-фраз: {len(s['words'])}\n"
                "Кнопки доступны администраторам. Числа: /set параметр значение")

    async def callback(self, q: CallbackQuery):
        if not isinstance(q.message, Message) or q.message.chat.type not in GROUPS:
            return await q.answer("Открой /settings в супергруппе.", show_alert=True)
        async with self.lock(q.message.chat.id):
            try:
                await self.require_admin(q.message.chat.id, q.from_user.id)
                key = (q.data or "").removeprefix("toggle:")
                if key not in BOOL_KEYS:
                    raise UserError("Неизвестная настройка.")
                s = await self.db.settings(q.message.chat.id)
                s[key] = not s[key]
                await self.db.save_settings(q.message.chat.id, s)
                await self.db.audit(q.message.chat.id, q.from_user.id, None, "setting", f"{key}={s[key]}")
                await q.answer("Сохранено")
                await q.message.edit_text(self.settings_text(s), reply_markup=self.keyboard(s))
            except UserError as e:
                await q.answer(str(e), show_alert=True)
            except TelegramAPIError:
                log.warning("Callback Telegram API failure")
                with suppress(TelegramAPIError):
                    await q.answer("Открой /settings заново.", show_alert=True)

    async def message(self, m: Message):
        async with self.lock(m.chat.id):
            try:
                await self.process(m)
            except (UserError, ValueError) as e:
                await m.answer(str(e))
            except TelegramAPIError as e:
                log.warning("Telegram operation failed: %s", type(e).__name__)
                if self.cooldowns.ready((m.chat.id, "api_error"), 60):
                    with suppress(TelegramAPIError):
                        await m.answer("Telegram не выполнил действие. Проверь /check, ID участника и возраст сообщения. Изменения могут быть выполнены частично; проверь /logs.")

    async def process(self, m: Message):
        command = parse_command(m.text or "", self.username)
        edited = m.edit_date is not None
        if m.chat.type not in GROUPS:
            if command and not edited:
                await m.answer(HELP if command[0] in {"start", "help"} else
                               "Добавь бота администратором в супергруппу. Справка: /help")
            return
        # Anonymous admins and channel identities cannot be reliably authorized as people.
        if m.sender_chat or not m.from_user or m.from_user.is_bot:
            return
        if m.new_chat_members:
            s = await self.db.settings(m.chat.id)
            if s["welcome"]:
                for user in m.new_chat_members:
                    if not user.is_bot:
                        await m.answer(s["welcome_text"].replace("{name}", user.full_name))
            return
        if m.content_type in {"left_chat_member", "pinned_message", "new_chat_title", "new_chat_photo",
                              "delete_chat_photo", "group_chat_created", "supergroup_chat_created"}:
            return
        admin = await self.is_admin(m.chat.id, m.from_user.id)
        if not admin and await self.filter_message(m, edited):
            return
        # Edited messages are filtered, but never execute moderation commands again.
        if command and not edited:
            if not admin and not self.cooldowns.ready((m.chat.id, m.from_user.id, "cmd"), 3):
                return
            await self.command(m, *command)

    async def filter_message(self, m, edited):
        s = await self.db.settings(m.chat.id)
        reason, flood = None, False
        text = m.text or m.caption or ""
        if not edited and s["antiflood"] and self.flood.hit(
                m.chat.id, m.from_user.id, s["flood_limit"], s["flood_window"]):
            reason, flood = "Флуд", True
        elif s["antilinks"] and contains_link(text, (m.entities or []) + (m.caption_entities or [])):
            reason = "Запрещённая ссылка"
        elif s["antiforward"] and m.forward_origin:
            reason = "Пересланное сообщение"
        elif s["stopwords"] and forbidden_word(text, s["words"]):
            reason = "Стоп-слово/фраза"
        if not reason:
            return False
        await self.require_bot(m.chat.id, "can_delete_messages")
        await self.bot.delete_message(m.chat.id, m.message_id)
        await self.db.audit(m.chat.id, self.bot.id, m.from_user.id, "delete", reason)
        if not self.cooldowns.ready((m.chat.id, m.from_user.id, "violation"), 10):
            return True
        if flood:
            await self.require_bot(m.chat.id, "can_restrict_members")
            await self.mute(m.chat.id, m.from_user.id, s["mute_minutes"] * 60)
            await self.db.audit(m.chat.id, self.bot.id, m.from_user.id, "automute", reason)
            await m.answer(f"🔇 ID {m.from_user.id}: мут на {s['mute_minutes']} мин. Причина: флуд.")
        else:
            await self.warn(m, m.from_user.id, reason, self.bot.id)
        return True

    async def command(self, m, cmd, args):
        chat, actor = m.chat.id, m.from_user.id
        if cmd in {"start", "help"}:
            return await m.answer(HELP)
        if cmd == "ping":
            return await m.answer(f"🟢 Работаю. С момента запуска: {int((time.monotonic()-self.started)/60)} мин.")
        if cmd == "id":
            uid = m.reply_to_message.from_user.id if m.reply_to_message and m.reply_to_message.from_user else actor
            return await m.answer(f"Группа: {chat}\nПользователь: {uid}")
        if cmd == "rules":
            return await m.answer((await self.db.settings(chat))["rules"])
        if cmd == "filters":
            s = await self.db.settings(chat)
            return await m.answer("\n".join(f"{k}: {'вкл' if s[k] else 'выкл'}" for k in sorted(BOOL_KEYS)))
        if cmd == "report":
            if not m.reply_to_message:
                raise UserError("Отправь /report ответом на сообщение, на которое жалуешься.")
            if not self.cooldowns.ready((chat, actor, "report"), 60):
                raise UserError("Жалобу можно отправлять раз в минуту.")
            uid = m.reply_to_message.from_user.id if m.reply_to_message.from_user else None
            await self.db.audit(chat, actor, uid, "report", args or "Жалоба")
            return await m.reply_to_message.reply(f"🚩 Администраторы, проверьте это сообщение. Жалоба от ID {actor}.\n{args[:300]}")
        if cmd == "warnings" and not args and not m.reply_to_message:
            return await m.answer(f"Твои предупреждения: {await self.db.count(chat, actor)}")

        right = "can_delete_messages" if cmd == "del" else (
            "can_restrict_members" if cmd in {"ban", "unban", "kick", "mute", "unmute", "warn", "unwarn", "resetwarns"} else None)
        await self.require_admin(chat, actor, right)
        if cmd == "check":
            member = await self.bot.get_chat_member(chat, self.bot.id)
            return await m.answer("Права бота:\n" + "\n".join(
                f"{name}: {'✅' if getattr(member, key, False) else '❌'}" for key, name in
                [("can_delete_messages", "Удаление сообщений"), ("can_restrict_members", "Блокировка участников")]))
        if cmd == "settings":
            s = await self.db.settings(chat)
            return await m.answer(self.settings_text(s), reply_markup=self.keyboard(s))
        if cmd == "set":
            parts = args.split()
            if len(parts) != 2 or parts[0] not in LIMITS:
                raise UserError("Пример: /set warn_limit 3\nПараметры: " + ", ".join(LIMITS))
            key, raw = parts
            if not raw.isdigit():
                raise UserError("Нужно целое положительное число.")
            value = int(raw)
            low, high = LIMITS[key]
            if not low <= value <= high:
                raise UserError(f"Допустимый диапазон: {low}–{high}.")
            s = await self.db.settings(chat)
            s[key] = value
            await self.db.save_settings(chat, s)
            await self.db.audit(chat, actor, None, "setting", args)
            return await m.answer("Сохранено: " + args)
        if cmd in {"setrules", "setwelcome"}:
            if not 1 <= len(args) <= 2000:
                raise UserError("Текст должен содержать от 1 до 2000 символов.")
            s = await self.db.settings(chat)
            s["rules" if cmd == "setrules" else "welcome_text"] = args
            await self.db.save_settings(chat, s)
            await self.db.audit(chat, actor, None, cmd)
            return await m.answer("Сохранено." + (" Включи приветствие в /settings." if cmd == "setwelcome" else ""))
        if cmd == "word":
            parts = args.split(maxsplit=1)
            s = await self.db.settings(chat)
            if parts == ["list"]:
                return await m.answer("Стоп-фразы:\n" + ("\n".join(s["words"]) or "пусто"))
            if len(parts) != 2 or parts[0] not in {"add", "del"}:
                raise UserError("/word add фраза • /word del фраза • /word list")
            word = normalize(parts[1]).strip()
            if not 1 <= len(word) <= 30:
                raise UserError("Длина стоп-фразы: 1–30 символов.")
            if parts[0] == "add" and word not in s["words"]:
                if len(s["words"]) >= 100:
                    raise UserError("Лимит: 100 стоп-фраз.")
                s["words"].append(word)
            elif parts[0] == "del" and word in s["words"]:
                s["words"].remove(word)
            await self.db.save_settings(chat, s)
            await self.db.audit(chat, actor, None, "word", args)
            return await m.answer("Стоп-фразы сохранены.")
        if cmd in {"logs", "stats"}:
            rows = await (self.db.logs(chat) if cmd == "logs" else self.db.stats(chat))
            lines = ([f"{datetime.fromtimestamp(r['at'], timezone.utc):%d.%m %H:%M} UTC | {r['action']} | {r['actor']} → {r['target']} | {r['reason'][:100]}" for r in rows]
                     if cmd == "logs" else [f"{r['action']}: {r['n']}" for r in rows])
            return await m.answer("\n".join(lines) or "Действий пока нет.")
        if cmd == "del":
            if not m.reply_to_message:
                raise UserError("Ответь командой /del на удаляемое сообщение.")
            await self.require_bot(chat, "can_delete_messages")
            await self.bot.delete_message(chat, m.reply_to_message.message_id)
            await self.db.audit(chat, actor, None, "delete", "Вручную")
            return await m.answer("Сообщение удалено.")
        uid, rest = await self.target(m, args, protect=cmd != "warnings")
        if cmd == "warnings":
            return await m.answer(f"ID {uid}: {await self.db.count(chat, uid)} предупреждений.")
        if cmd in {"unwarn", "resetwarns"}:
            n = await self.db.change_warns(chat, uid, -1, reset=cmd == "resetwarns")
            await self.db.audit(chat, actor, uid, cmd)
            return await m.answer(f"ID {uid}: осталось {n} предупреждений.")
        if cmd == "warn":
            return await self.warn(m, uid, rest or "Нарушение правил", actor)
        await self.require_bot(chat, "can_restrict_members")
        if cmd == "mute":
            pieces = rest.split(maxsplit=1)
            if not pieces:
                raise UserError("Укажи срок: /mute 30m причина")
            seconds = duration(pieces[0])
            await self.mute(chat, uid, seconds)
            result = f"Мут на {seconds // 60} мин."
        elif cmd == "unmute":
            await self.bot.restrict_chat_member(chat, uid,
                permissions=ChatPermissions(**{k: True for k in ChatPermissions.model_fields}),
                use_independent_chat_permissions=True)
            result = "Персональные ограничения сняты; действуют общие права группы."
        elif cmd == "ban":
            await self.bot.ban_chat_member(chat, uid)
            result = "Участник забанен."
        elif cmd == "unban":
            await self.bot.unban_chat_member(chat, uid, only_if_banned=True)
            result = "Бан снят. Участник может вернуться по приглашению."
        elif cmd == "kick":
            await self.bot.ban_chat_member(chat, uid)
            # Audit the first API action even if the second fails.
            await self.db.audit(chat, actor, uid, "kick_ban", rest)
            await self.bot.unban_chat_member(chat, uid, only_if_banned=True)
            result = "Участник удалён и может вернуться."
        else:
            raise UserError("Неизвестная команда.")
        await self.db.audit(chat, actor, uid, cmd, rest)
        await m.answer(f"✅ ID {uid}. {result}" + (f"\n{rest[:300]}" if rest else ""))

    def dispatcher(self):
        dp = Dispatcher()
        dp.message.register(self.message)
        dp.edited_message.register(self.message)
        dp.callback_query.register(self.callback, F.data.startswith("toggle:"))
        return dp
