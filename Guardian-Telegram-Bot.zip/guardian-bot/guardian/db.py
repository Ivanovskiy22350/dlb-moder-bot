import asyncio
import json
import time
from pathlib import Path

import aiosqlite

from .policy import DEFAULTS


class Database:
    def __init__(self, path):
        self.path = path
        self.lock = asyncio.Lock()

    async def open(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA busy_timeout=5000;
            CREATE TABLE IF NOT EXISTS settings(chat INTEGER PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS warnings(
                chat INTEGER, user INTEGER, count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(chat,user));
            CREATE TABLE IF NOT EXISTS audit(
                id INTEGER PRIMARY KEY AUTOINCREMENT, chat INTEGER NOT NULL,
                actor INTEGER NOT NULL, target INTEGER, action TEXT NOT NULL,
                reason TEXT NOT NULL, at INTEGER NOT NULL);
            CREATE INDEX IF NOT EXISTS audit_chat_id ON audit(chat,id);
            CREATE INDEX IF NOT EXISTS audit_at ON audit(at);
        """)
        await self.conn.commit()
        await self.prune()
        return self

    async def close(self):
        await self.conn.close()

    async def settings(self, chat):
        async with self.lock:
            async with self.conn.execute("SELECT value FROM settings WHERE chat=?", (chat,)) as cur:
                row = await cur.fetchone()
        return {**DEFAULTS, **(json.loads(row[0]) if row else {}),
                "words": list(json.loads(row[0]).get("words", []) if row else [])}

    async def save_settings(self, chat, settings):
        async with self.lock:
            await self.conn.execute("INSERT OR REPLACE INTO settings VALUES(?,?)",
                                    (chat, json.dumps(settings, ensure_ascii=False)))
            await self.conn.commit()

    async def count(self, chat, user):
        async with self.lock:
            async with self.conn.execute("SELECT count FROM warnings WHERE chat=? AND user=?",
                                         (chat, user)) as cur:
                row = await cur.fetchone()
        return row[0] if row else 0

    async def change_warns(self, chat, user, delta=0, reset=False):
        async with self.lock:
            if reset:
                await self.conn.execute("DELETE FROM warnings WHERE chat=? AND user=?", (chat, user))
                result = 0
            else:
                await self.conn.execute("""INSERT INTO warnings VALUES(?,?,MAX(0,?))
                    ON CONFLICT(chat,user) DO UPDATE SET count=MAX(0,count+?)""",
                                        (chat, user, delta, delta))
                async with self.conn.execute("SELECT count FROM warnings WHERE chat=? AND user=?",
                                             (chat, user)) as cur:
                    result = (await cur.fetchone())[0]
            await self.conn.commit()
        return result

    async def audit(self, chat, actor, target, action, reason=""):
        async with self.lock:
            await self.conn.execute("INSERT INTO audit(chat,actor,target,action,reason,at) VALUES(?,?,?,?,?,?)",
                                    (chat, actor, target, action, reason[:300], int(time.time())))
            await self.conn.commit()

    async def logs(self, chat):
        async with self.lock:
            async with self.conn.execute("SELECT * FROM audit WHERE chat=? ORDER BY id DESC LIMIT 10",
                                         (chat,)) as cur:
                return await cur.fetchall()

    async def stats(self, chat):
        async with self.lock:
            async with self.conn.execute("SELECT action,COUNT(*) AS n FROM audit WHERE chat=? GROUP BY action",
                                         (chat,)) as cur:
                return await cur.fetchall()

    async def prune(self):
        async with self.lock:
            await self.conn.execute("DELETE FROM audit WHERE at<?", (int(time.time()) - 90 * 86400,))
            await self.conn.commit()
