import re
import time
import unicodedata
from collections import OrderedDict, deque

ALIASES = {
    "бан": "ban", "разбан": "unban", "мут": "mute", "размут": "unmute",
    "варн": "warn", "пред": "warn", "снятьпред": "unwarn", "преды": "warnings",
    "кик": "kick", "удалить": "del", "правила": "rules", "настройки": "settings",
    "помощь": "help", "пинг": "ping", "ид": "id",
}
COMMANDS = set(ALIASES.values()) | {
    "start", "help", "check", "setrules", "setwelcome", "set", "word",
    "logs", "stats", "resetwarns", "report", "filters",
}
BOOL_KEYS = {"antiflood", "antilinks", "antiforward", "welcome", "stopwords"}
DEFAULTS = {
    "antiflood": True, "antilinks": False, "antiforward": False,
    "stopwords": True, "welcome": False, "flood_limit": 7, "flood_window": 10,
    "warn_limit": 3, "mute_minutes": 60, "rules": "Правила пока не заданы.",
    "welcome_text": "Добро пожаловать, {name}! Правила: /rules", "words": [],
}
LIMITS = {"flood_limit": (3, 30), "flood_window": (3, 60),
          "warn_limit": (2, 20), "mute_minutes": (1, 10080)}


def parse_command(text: str, username: str):
    if not text or text[0] not in "/!":
        return None
    parts = text[1:].split(maxsplit=1)
    if not parts:
        return None
    name, _, addressed = parts[0].partition("@")
    if addressed and addressed.casefold() != username.casefold():
        return None
    name = ALIASES.get(name.casefold(), name.casefold())
    if name not in COMMANDS:
        return None
    return name, parts[1].strip() if len(parts) > 1 else ""


def duration(value: str) -> int:
    match = re.fullmatch(r"(\d{1,6})([mhdмчд])", value.casefold())
    if not match:
        raise ValueError("Время: 10m, 2h, 7d (или 10м, 2ч, 7д).")
    seconds = int(match[1]) * {"m": 60, "м": 60, "h": 3600, "ч": 3600,
                               "d": 86400, "д": 86400}[match[2]]
    if not 60 <= seconds <= 365 * 86400:
        raise ValueError("Срок должен быть от 1 минуты до 365 дней.")
    return seconds


def normalize(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKC", text).casefold()
                   if unicodedata.category(c) != "Cf")


def forbidden_word(text: str, words: list[str]) -> bool:
    text = normalize(text)
    return any(re.search(r"(?<!\w)" + re.escape(normalize(w)) + r"(?!\w)", text)
               for w in words)


def contains_link(text: str, entities=()) -> bool:
    # Telegram entities also cover concealed hyperlinks in captions.
    if any(e.type in {"url", "text_link"} for e in entities):
        return True
    return bool(re.search(r"(?i)(?:https?://|tg://|www\.|(?:t|telegram)\.me/)", normalize(text)))


class FloodGuard:
    """Bounded, monotonic sliding window; edits do not count as new messages."""
    def __init__(self, capacity=20000):
        self.capacity = capacity
        self.windows = OrderedDict()

    def hit(self, chat, user, limit, window, now=None):
        now = time.monotonic() if now is None else now
        key = (chat, user)
        timestamps = self.windows.pop(key, deque(maxlen=31))
        while timestamps and timestamps[0] <= now - window:
            timestamps.popleft()
        timestamps.append(now)
        self.windows[key] = timestamps
        while len(self.windows) > self.capacity:
            self.windows.popitem(last=False)
        return len(timestamps) > limit


class Cooldowns:
    def __init__(self, capacity=20000):
        self.values = OrderedDict()
        self.capacity = capacity

    def ready(self, key, seconds):
        now = time.monotonic()
        if now < self.values.get(key, 0):
            return False
        self.values.pop(key, None)
        self.values[key] = now + seconds
        while len(self.values) > self.capacity:
            self.values.popitem(last=False)
        return True
