"""SQLite online backup: python scripts/backup.py [output-directory]."""
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()
source = Path(os.getenv("DB_PATH", "data/guardian.sqlite3")).resolve()
if not source.is_file():
    raise SystemExit("База не найдена; сначала запусти бота.")
folder = Path(sys.argv[1] if len(sys.argv) > 1 else "backups")
folder.mkdir(parents=True, exist_ok=True)
destination = folder / ("guardian-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f") + ".sqlite3")
with sqlite3.connect(source.as_uri() + "?mode=ro", uri=True) as src:
    with sqlite3.connect(destination) as dst:
        src.backup(dst)
print(destination)
