import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from aiogram.types import Message, Chat, User, CallbackQuery

from guardian.app import Guardian, UserError
from guardian.db import Database


@pytest_asyncio.fixture
async def db(tmp_path):
    database = await Database(str(tmp_path / "bot.sqlite3")).open()
    yield database
    await database.close()


def message(text, actor=1, reply_user=None, edited=False):
    m = Message(message_id=10, date=datetime.now(timezone.utc),
                chat=Chat(id=-100123, type="supergroup"),
                from_user=User(id=actor, is_bot=False, first_name="Admin"), text=text,
                edit_date=int(datetime.now(timezone.utc).timestamp()) if edited else None,
                reply_to_message=Message(message_id=9, date=datetime.now(timezone.utc),
                    chat=Chat(id=-100123, type="supergroup"),
                    from_user=User(id=reply_user, is_bot=False, first_name="Member"), text="text")
                if reply_user else None)
    return m


def bot_mock():
    bot = AsyncMock()
    bot.id = 999
    async def member(chat, uid):
        return SimpleNamespace(status="administrator" if uid in {1, 999} else "member",
                               can_delete_messages=True, can_restrict_members=True)
    bot.get_chat_member.side_effect = member
    return bot


@pytest.mark.asyncio
async def test_database_persistence_and_isolation(tmp_path):
    path = str(tmp_path / "persist.sqlite3")
    db = await Database(path).open()
    await asyncio.gather(*(db.change_warns(1, 20, 1) for _ in range(20)))
    s = await db.settings(1)
    s["words"].append("спам")
    await db.save_settings(1, s)
    await db.close()
    db = await Database(path).open()
    try:
        assert await db.count(1, 20) == 20
        assert await db.count(2, 20) == 0
        assert (await db.settings(1))["words"] == ["спам"]
        assert (await db.settings(2))["words"] == []
        await db.change_warns(1, 20, reset=True)
        assert await db.change_warns(1, 20, -1) == 0
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_regular_user_cannot_ban_or_change_settings(db):
    bot = bot_mock()
    app = Guardian(bot, db, "guardbot")
    for actor, text in enumerate(("/ban 5", "/set warn_limit 10"), start=2):
        with pytest.raises(UserError, match="администраторам"):
            await app.process(message(text, actor=actor))
    bot.ban_chat_member.assert_not_called()
    assert (await db.settings(-100123))["warn_limit"] == 3


@pytest.mark.asyncio
async def test_admin_self_and_other_admin_protected(db):
    app = Guardian(bot_mock(), db, "guardbot")
    for uid in (1, 999):
        with pytest.raises(UserError, match="Нельзя"):
            await app.target(message("/ban", reply_user=uid), "")


@pytest.mark.asyncio
async def test_missing_admin_right_rejected(db):
    bot = bot_mock()
    bot.get_chat_member.side_effect = None
    bot.get_chat_member.return_value = SimpleNamespace(status="administrator", can_restrict_members=False)
    app = Guardian(bot, db, "guardbot")
    with pytest.raises(UserError, match="нет необходимого"):
        await app.command(message("/ban 5"), "ban", "5")
    bot.ban_chat_member.assert_not_called()


@pytest.mark.asyncio
async def test_edits_never_repeat_commands(db):
    app = Guardian(bot_mock(), db, "guardbot")
    app.command = AsyncMock()
    await app.process(message("/ban 5", edited=True))
    app.command.assert_not_called()


@pytest.mark.asyncio
async def test_existing_restriction_not_overwritten(db):
    bot = bot_mock()
    bot.get_chat_member.side_effect = None
    bot.get_chat_member.return_value = SimpleNamespace(status="restricted")
    app = Guardian(bot, db, "guardbot")
    with pytest.raises(UserError, match="уже ограничен"):
        await app.mute(-100123, 5, 60)
    bot.restrict_chat_member.assert_not_called()


@pytest.mark.asyncio
async def test_warn_threshold_resets_only_after_success(db):
    bot = bot_mock()
    app = Guardian(bot, db, "guardbot")
    m = SimpleNamespace(chat=SimpleNamespace(id=-100123), answer=AsyncMock())
    app.mute = AsyncMock(side_effect=UserError("no rights"))
    for _ in range(3):
        await app.warn(m, 5, "спам", 1)
    assert await db.count(-100123, 5) == 3
    app.mute.side_effect = None
    await app.warn(m, 5, "спам", 1)
    assert await db.count(-100123, 5) == 0


@pytest.mark.asyncio
async def test_callback_rechecks_current_admin(db):
    bot = bot_mock()
    app = Guardian(bot, db, "guardbot")
    q = SimpleNamespace(message=message("settings"), from_user=SimpleNamespace(id=2),
                        data="toggle:antilinks", answer=AsyncMock())
    await app.callback(q)
    assert not (await db.settings(-100123))["antilinks"]
    assert q.answer.call_args.kwargs["show_alert"]


@pytest.mark.asyncio
async def test_filter_checks_edited_captions(db):
    bot = bot_mock()
    app = Guardian(bot, db, "guardbot")
    s = await db.settings(-100123)
    s["antilinks"] = True
    await db.save_settings(-100123, s)
    app.warn = AsyncMock()
    m = message("", actor=2, edited=True).model_copy(update={"text": None, "caption": "https://example.org"})
    assert await app.filter_message(m, edited=True)
    bot.delete_message.assert_awaited_once_with(-100123, 10)
    app.warn.assert_awaited_once()


@pytest.mark.asyncio
async def test_unban_does_not_kick_member(db, monkeypatch):
    bot = bot_mock()
    app = Guardian(bot, db, "guardbot")
    monkeypatch.setattr(Message, "answer", AsyncMock())
    await app.command(message("/unban 5"), "unban", "5")
    bot.unban_chat_member.assert_awaited_once_with(-100123, 5, only_if_banned=True)


@pytest.mark.asyncio
async def test_mute_denies_all_message_types(db):
    bot = bot_mock()
    app = Guardian(bot, db, "guardbot")
    await app.mute(-100123, 5, 60)
    kwargs = bot.restrict_chat_member.call_args.kwargs
    assert kwargs["use_independent_chat_permissions"] is True
    assert all(v is False for v in kwargs["permissions"].model_dump().values())
    assert kwargs["until_date"] > datetime.now(timezone.utc)
