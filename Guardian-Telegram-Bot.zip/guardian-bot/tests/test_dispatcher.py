"""Exercise aiogram routing and real Telegram method models without network."""
import time

import pytest
from aiogram import Bot
from aiogram.client.session.base import BaseSession
from aiogram.types import ChatMemberAdministrator, ChatMemberMember, ChatMemberOwner, Message, Update, User

from guardian.app import Guardian
from guardian.db import Database


class FakeTelegram(BaseSession):
    def __init__(self):
        super().__init__()
        self.calls = []

    async def close(self):
        pass

    async def stream_content(self, *args, **kwargs):
        if False:
            yield b""

    async def make_request(self, bot, method, timeout=None):
        self.calls.append(method)
        name = method.__api_method__
        if name == "getChatMember":
            user = User(id=method.user_id, is_bot=method.user_id == bot.id, first_name="Test")
            if method.user_id == bot.id:
                flags = {k: True for k in ChatMemberAdministrator.model_fields
                         if k.startswith("can_") or k == "is_anonymous"}
                return ChatMemberAdministrator(user=user, **flags)
            if method.user_id == 1:
                return ChatMemberOwner(user=user, is_anonymous=False)
            return ChatMemberMember(user=user)
        if name == "sendMessage":
            assert len(method.text) <= 4096
            return Message(message_id=50, date=int(time.time()),
                           chat={"id": method.chat_id, "type": "supergroup"}, text=method.text)
        return True


@pytest.mark.asyncio
@pytest.mark.parametrize("actor,expected", [(1, True), (2, False)])
async def test_real_dispatcher_mute_authorization(tmp_path, actor, expected):
    db = await Database(str(tmp_path / "state.sqlite3")).open()
    session = FakeTelegram()
    # Intentionally synthetic: this session never connects to Telegram.
    bot = Bot("999:TEST_TOKEN_FOR_LOCAL_TESTS_ONLY", session=session)
    try:
        app = Guardian(bot, db, "guardbot")
        dp = app.dispatcher()
        update = Update(update_id=1, message=Message(
            message_id=10, date=int(time.time()), chat={"id": -100123, "type": "supergroup"},
            from_user=User(id=actor, is_bot=False, first_name="Caller"), text="!мут 5 30м спам"))
        await dp.feed_update(bot, update)
        restrictions = [m for m in session.calls if m.__api_method__ == "restrictChatMember"]
        assert bool(restrictions) == expected
        assert any(m.__api_method__ == "sendMessage" for m in session.calls)
        if expected:
            assert restrictions[0].user_id == 5
            assert restrictions[0].permissions.can_send_messages is False
            assert (await db.logs(-100123))[0]["action"] == "mute"
    finally:
        await bot.session.close()
        await db.close()
