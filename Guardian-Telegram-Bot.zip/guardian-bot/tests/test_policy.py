from types import SimpleNamespace

import pytest

from guardian.policy import FloodGuard, contains_link, duration, forbidden_word, parse_command


def test_command_alias_and_bot_address():
    assert parse_command("!мут 20m спам", "guardianbot") == ("mute", "20m спам")
    assert parse_command("/ban@GuardianBot 123", "guardianbot") == ("ban", "123")
    assert parse_command("/ban@otherbot 123", "guardianbot") is None
    assert parse_command("просто текст", "guardianbot") is None


@pytest.mark.parametrize("value", ["0m", "0h", "-1h", "999999d", "366d", "20", "permanent"])
def test_unsafe_durations_rejected(value):
    with pytest.raises(ValueError):
        duration(value)


def test_duration():
    assert duration("2ч") == 7200
    assert duration("365d") == 31536000


def test_flood_is_scoped_and_expires():
    guard = FloodGuard(capacity=2)
    for t in (0, 1, 2):
        assert not guard.hit(1, 10, 3, 10, t)
    assert guard.hit(1, 10, 3, 10, 3)
    assert not guard.hit(2, 10, 3, 10, 3)
    assert not guard.hit(1, 10, 3, 10, 14)
    guard.hit(3, 20, 3, 10, 14)
    assert len(guard.windows) == 2


def test_hidden_links_and_word_boundaries():
    assert contains_link("нажми", [SimpleNamespace(type="text_link")])
    assert contains_link("t.me/example")
    assert forbidden_word("СП\u200bАМ!", ["спам"])
    assert not forbidden_word("спамить", ["спам"])
    assert forbidden_word("Здесь купить сейчас!", ["купить сейчас"])
